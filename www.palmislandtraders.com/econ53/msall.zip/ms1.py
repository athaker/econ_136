# MacroSim1 2018 Developed by Prof Evans for Econ 53
# This is the initial model converted from C++ to Python.
# This is version 3.4, dated March 1, 2018.
# Default model values: a:100,b:0.75,t:0.20,G:600,I:420
# Initialize variables
# Assumptions
#
a = 100.0
b = 0.75
I = 420
#
# Policy variables
t = 0.20
G = 600
#
#
# Solve
#
m = (1/(1-b*(1-t)))
Y = (I + G + a)*m
YD = (1-t)*Y
C = a + (b*YD)
taxes = t*Y
D = G - taxes
S = YD - C
print("")
print("ASSUMPTIONS")
print ("Autonomous consumption(a) =", '{:.3f}'.format(a))
print ("Consumption coefficient(b) =", '{:.3f}'.format(b))
print ("Investment (I) = ", '{:.2f}'.format(I))
print("")
print ("POLICY VARIABLES")
print ("Tax rate (t) =", '{:.3f}'.format(t))
print ("Government spending (G) = ", '{:.2f}'.format(G))
print ("")
print ("SIMULATION RESULTS")
print ("Multiplier (m) =", '{:.3f}'.format(m))
print ("GDP (Y) = ", '{:.2f}'.format(Y))
print ("Disposable Personal Income (YD) = ", '{:.2f}'.format(YD))
print ("Consumption (C) = ", '{:.2f}'.format(C))
print ("Taxes collected (taxes) = ", '{:.2f}'.format(taxes))
print ("Budget Deficit (D) =", '{:.2f}'.format(D))
print ("Savings (S) =", '{:.2f}'.format(S))
print ("")
print ("IDENTITY CHECKS")
S = I + D
print ("Check S =", '{:.2f}'.format(S))
Y = C + I + G
print ("Check Y = ", '{:.2f}'.format(Y))
print ("")

