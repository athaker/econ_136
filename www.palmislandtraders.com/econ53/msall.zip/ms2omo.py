# ms2omo.py 2018 Developed by Prof Evans for Econ 53
# This is the MS2 model that calculates credit growth rates
# based upon reserve expansion instead of money supply growth
# rates. This model also lets you change the reserve requirement.
# This is version 3.2, dated April 10, 2018.
# Investment elasticity was reset to approx 1 in this version.
# Default model values: a:100,b:0.75,t:0.20,G:600,h:820,e:160
# d:-10000.0,f:6000.0,reserves:1200.0,resreq:0.10,debt:1200,resgr:0.05.
#
# Initialize variables
#
h = 820.0
d = -10000.0
f = 6000.0
reserves = 120
resreq = 0.10
debt = 1200.0
resgr = 0.05
e = 160.0
a = 100.0
b = 0.75
t = 0.20
G = 600
#
# Solve for the interest rate, credit growth, I, and SF, DF and
# debt (Loanable Funds Model). Debt is a residual value.
#
credit = reserves*(1.0/resreq)*resgr
debt = debt+ credit
X1 = a + G + h + d*((e + credit - h - G)/(d-f))
X2 = (1 - (b*(1 - t)) - ((d*t)/(d - f)))
Y = (X1/X2)
YD = (1-t)*Y
C = a + (b*YD)
taxes = t*Y
D = G - taxes
r = (e + credit - h - D)/(d-f)
I = h + (d*r)
DF = I + D
S = e + (f*r)
SF = S + credit

print ("")
print ("ASSUMPTIONS:")
print ("Autonomous consumption(a) =", '{:.3f}'.format(a))
print ("Consumption coefficient(b) =", '{:.3f}'.format(b))
print ("Investment intercept (h) =", '{:.1f}'.format(h))
print ("Investment slope (d) =", '{:.2f}'.format(d))
print ("Savings intercept(e) =", '{:.1f}'.format(e))
print ("Savings slope (f) =", '{:.2f}'.format(f))
print ("Debt (debt) =", '{:.1f}'.format(debt))
print ("Bank reserves (reserves) =", '{:.1f}'.format(reserves))
print ("")
print ("POLICY VARIABLES:")
print ("Reserve Growth Rate (resgr) =", '{:.4f}'.format(resgr))
print ("Reserve Requirement (resreq) =", '{:.4f}'.format(resreq))
print ("Government spending (G) = ", '{:.2f}'.format(G))
print ("Tax rate (t) =", '{:.3f}'.format(t))
print ("")
print ("SIMULATION RESULTS:")
print ("GDP (Y) = ", '{:.2f}'.format(Y))
print ("Disposable Personal Income (YD) = ", '{:.2f}'.format(YD))
print ("Consumption (C) = ", '{:.2f}'.format(C))
print ("Interest Rate (r) =", '{:.4f}'.format(r))
print ("Investment (I) =", '{:.1f}'.format(I))
print ("Taxes collected (taxes) = ", '{:.2f}'.format(taxes))
print ("Budget Deficit (D) =", '{:.2f}'.format(D))
print ("Demand for Funds (DF) =", '{:.1f}'.format(DF))
print ("Savings (S) =", '{:.2f}'.format(S))
print ("New Credit (credit) =", '{:.2f}'.format(credit))
print ("Debt (debt) =", '{:.2f}'.format(debt))
print ("Supply of Funds (S) =", '{:.1f}'.format(SF))
# print ("Multiplier (m) =", '{:.3f}'.format(m))
Y = I + C + G
print ("Y test = ", '{:.2f}'.format(Y))
# S = YD - C
# print ("S test = ", '{:.2f}'.format(S))





