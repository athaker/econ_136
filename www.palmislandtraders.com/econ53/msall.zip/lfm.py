# The Loanable Funds Model simulator
# This model is designed for inclusion in MacroSim2
# Default assumptions: h:600, d:-4500, f:6000
# ms:1200, e:160, msgr: 0.05, D: 40
# lfm.py version 2.2 March 1, 2018
#
# Assumptions
#
h = 600
d = -4500.0
f = 6000.0
ms = 1200.0
e = 160.0
#
# Policy inputs
msgr = 0.05
D = 40.0
#
# Solve for the interest rate
#
dMS = ms*msgr
r = (D - dMS + h - e)/(f-d)
I = h + (d*r)
DF = I + D
S = e + (f*r)
SF = S + dMS
#
# Solve for elasticities
#
eS = f*(r/S)
eI = d*(r/I)
#
# Print results
#
print ("")
print ("ASSUMPTIONS:")
print ("Investment intercept (h) =", '{:.1f}'.format(h))
print ("Investment slope (d) =", '{:.2f}'.format(d))
print ("Savings intercept(e) =", '{:.1f}'.format(e))
print ("Savings slope (f) =", '{:.2f}'.format(f))
print ("Money supply (ms) =", '{:.1f}'.format(ms))
print ("")
print ("POLICY VARIABLES:")
print ("Money supply growth rate (msgr) =", '{:.4f}'.format(msgr))
print ("Budget Deficit (D) =", '{:.1f}'.format(D))
print ("")
print ("SIMULATION RESULTS:")
print ("Money Supply Increase (dMS) =", '{:.1f}'.format(dMS))
print ("Interest Rate (r) =", '{:.4f}'.format(r))
print ("Investment (I) =", '{:.1f}'.format(I))
print ("Savings (S) =", '{:.1f}'.format(S))
print ("Demand for Funds (DF) =", '{:.1f}'.format(DF))
print ("Supply of Funds (SF) =", '{:.1f}'.format(SF))
print ("")
print ("ELASTICITIES")
print ("Savings elasticity (eS) =", '{:.3f}'.format(eS))
print ("Investment elasticity (eI) =", '{:.3f}'.format(eI))

