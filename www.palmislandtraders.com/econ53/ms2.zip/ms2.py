# MacroSim2 2018 Developed by Prof Evans for Econ 53
# This is the initial model converted from C++ to Python.
# This is version 3.2, dated March 1, 2018.
# Default model values: a:100,b:0.75,t:0.20,G:600, h:600, e:160
# (Default continued): d:-4500.0, f:6000.0, ms:1200.0, msgr: 0.05
# Initialize variables
#
h = 600.0
d = -4500.0
f = 6000.0
ms = 1200.0
msgr = 0.05
e = 160.0
a = 100.0
b = 0.75
t = 0.20
G = 600
#
# Solve for the interest rate, ms growth, I, and Solve
# (Loanable Funds Model)
#
dMS = ms*msgr
X1 = a + G + h + d*((e + dMS - h - G)/(d-f))
X2 = (1 - (b*(1 - t)) - ((d*t)/(d - f)))
Y = (X1/X2)
YD = (1-t)*Y
C = a + (b*YD)
taxes = t*Y
D = G - taxes
r = (e + dMS - h - D)/(d-f)
I = h + (d*r)
DF = I + D
S = e + (f*r)
SF = S + dMS

print ("")
print ("ASSUMPTIONS:")
print ("Autonomous consumption(a) =", '{:.3f}'.format(a))
print ("Consumption coefficient(b) =", '{:.3f}'.format(b))
print ("Investment intercept (h) =", '{:.1f}'.format(h))
print ("Investment slope (d) =", '{:.2f}'.format(d))
print ("Savings intercept(e) =", '{:.1f}'.format(e))
print ("Savings slope (f) =", '{:.2f}'.format(f))
print ("Money supply (ms) =", '{:.1f}'.format(ms))
print ("")
print ("POLICY VARIABLES:")
print ("Money Supply Growth Rate (msgr) =", '{:.4f}'.format(msgr))
print ("Government spending (G) = ", '{:.2f}'.format(G))
print ("Tax rate (t) =", '{:.3f}'.format(t))
print ("")
print ("SIMULATION RESULTS:")
print ("GDP (Y) = ", '{:.2f}'.format(Y))
print ("Disposable Personal Income (YD) = ", '{:.2f}'.format(YD))
print ("Consumption (C) = ", '{:.2f}'.format(C))
print ("Interest Rate (r) =", '{:.4f}'.format(r))
print ("Investment (I) =", '{:.1f}'.format(I))
print ("Taxes collected (taxes) = ", '{:.2f}'.format(taxes))
print ("Budget Deficit (D) =", '{:.2f}'.format(D))
print ("Demand for Funds (DF) =", '{:.1f}'.format(DF))
print ("Savings (S) =", '{:.2f}'.format(S))
print ("Supply of Funds (S) =", '{:.1f}'.format(SF))
# print ("Multiplier (m) =", '{:.3f}'.format(m))
Y = I + C + G
print ("Y test = ", '{:.2f}'.format(Y))
# S = YD - C
# print ("S test = ", '{:.2f}'.format(S))





