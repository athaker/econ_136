# call_idv_qd.py (modified from call_idv_bsdc.py) in PyGo\PyFi
# [call, implied daily volatility, black-scholes, divide and conquer,
# quick and dirty]
# This is the BSM IDV model for calls only, using divide and conquer iteration 
# for conversion.
# This version accepts interest rates.
# Important! The version calls utilities from finutil.py and timeutil.py
# This version DOES NOT calculates days to expiry from today.
# This version does not calculate time decay.
# 
# Version 1.1 Dated April 4, 2020   Prof. Gary Evans
#
import math
import time
from datetime import date
import finutil as fu
#
#  USER INPUT SECTION
#
prog_name = "call_idv_qd_v1_1"
analyst = "Prof Evans"
#
# In this version the user provides days to expiry.
#
stosym = "SPY"
stopr = float(248.50)
strike = float(251.00)
callBid = float(6.98)
callAsk = float(7.05)
rfir = float (0.0100)
days = int(13)
peg_spr = 0.50   # location in bid/ask spread for PEG
#
# Calculate the PEG and make that your call price (market value).
#
spread = callAsk - callBid
callpr = callBid + ((peg_spr)*spread)
#
#  END USER INPUT (no changes go below)
#
#  Divide and conquer requires that we initialize before we start to
#  converge, using default upper and lower ranges and desired precision.
#  The variable cipd will eventually become our solution.
#
target = callpr
precision = float(1e-3)
count = 0
low = 0.0
high = 1.0
cipd = float((high+low)/2)
temp_cp_tu = fu.copo_pitm(stopr,strike,cipd,days,rfir)  # passes out a tuple
tempcp = temp_cp_tu[0]
while tempcp<=(target-precision) or tempcp>=(target+precision):
	if tempcp >= (target+precision):
		high = cipd
	else: 
		low = cipd
	cipd = float((high+low)/2)
	temp_cp_tu = fu.copo_pitm(stopr,strike,cipd,days,rfir) 
	tempcp = temp_cp_tu[0]
#
delta = temp_cp_tu[1]
prob_itm = temp_cp_tu[3]
#
print ("")
# print ("  Analyst: ", analyst)  # Use if turning in homework
print ("  Model and version: ", prog_name)  # Very useful when logging results.
print ("  ASSUMPTIONS:")
print ("  Stock price: {:.3f}".format(stopr))
print ("  Strike price: {:.2f} ".format(strike))
print ("  Days to expiry: {} ".format(days))
print ("  Interest rate: {:.3f} ".format(rfir))
print ("  Call Ask: {:.3f}".format(callAsk))
print ("  Call Bid: {:.3f}".format(callBid))
print ("  MODEL RESULTS:")
print ("  Call price (PEG): {:.3f}".format(callpr))
print ("  The delta: {:.3f}".format(delta))
print ("  The probability of ITM at expiry: {:.4f}".format(prob_itm))
print ("  The call's implied probability: {:.5f}".format(cipd))





