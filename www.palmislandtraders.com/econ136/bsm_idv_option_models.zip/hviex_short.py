#  hviex_short.py
#  Version 3.1 dated February 6, 2020
#  For documentation see the Jupyter master of this program, hviexmaster_short_vX.ipynd
#  Developed by Professor Evans
#
import pandas as pd
import numpy as np
import math
import sys
sys.path.append('c:/Users/Prof Gary Evans/Dropbox/PyGo/PyFi')
import finutil as fu
#
# User supplied information:
#
stocksym = "SPY"
token = "pk_8876ae7f70854c6d96a7ccf6a9dacccd"
#
# Setting upper case
#
stocksymlo = stocksym.lower()
stocksymup = stocksym.upper()
stocksym = stocksymup
#
# Set up Pandas, open IEXCloud to extract the data and calculate log growth rates:
#
stock = pd.DataFrame()
stock = pd.read_json('https://cloud.iexapis.com/stable/stock/'+stocksym+'/chart/1y?token='+token+'')
length = len(stock)
stock.reset_index()
stock = stock[['date','open','high','low','close','volume']]
price = np.array(stock.close)
pricep1 = np.roll(price,1)
lnratio = price/pricep1
cgr = np.log(lnratio)
cgr[0]= 0.00
stock['cgr'] = cgr
stock = stock[['date','open','high','low','close','volume','cgr']]
#
# Calculate drift, volatility, and Sharpe estimates
#
tspan = (length-1, 90, 30) # 1-year, 90-day, 30-day.
spans = len(tspan)            
vol = np.zeros(spans)
maxsigma = np.zeros(spans)
minsigma = np.zeros(spans)
drift = np.zeros(spans)
sharpe = np.zeros(spans)
xsigma = np.zeros((length,spans))
#
# Build the dataframe and display it
#
for i in range(0,spans):
    start_count = length - tspan[i]
    drift[i] = np.mean(cgr[start_count:length])
    vol[i] = np.std(cgr[start_count:length])
    sharpe[i] = drift[i]/vol[i]
    xsigma[start_count:length,i] = (cgr[start_count:length]- drift[i])/vol[i]
    maxsigma[i] = np.amax(xsigma[0:length,i])
    minsigma[i] = np.amin(xsigma[0:length,i])
#
coltitles = ['Drift','Volatility','Sharpe','Maxsigma','Minsigma']
rowtitles = ['1 year', '90 day', '30 day']
findata = np.zeros(spans*5)
findata = findata.reshape((5,spans))
findata[0:]=drift
findata[1:]=vol
findata[2:]=sharpe
findata[3:]=maxsigma
findata[4:]=minsigma
findata = findata.transpose()
volgrid = pd.DataFrame(findata)
volgrid.index = rowtitles
volgrid.columns = coltitles
#
print(" ",stocksym)
print("  Length :", length)
print(stock.tail(2))
print("")
print(volgrid)
