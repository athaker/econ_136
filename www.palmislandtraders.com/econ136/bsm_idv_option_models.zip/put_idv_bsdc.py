# put_idv_bsdc.py (modified from putidvex) in PyGo\PyFi
# [put, implied daily volatility, black-scholes, divide and conquer]
# This is the BSM IDV model for puts only, using divide and conquer iteration 
# for conversion.
# This version accepts interest rates.
# Important! The version calls utilities from finutil.py and timeutil.py
# This version calculates days to expiry from today.
# NOTE! This model won't run unless option expiry date in in the future.
# 
# Version 1.2 Dated April 4, 2020   Prof. Gary Evans
#
import math
import time
from datetime import date
import finutil as fu
import timeutil as tu
#
#  USER INPUT SECTION
#
prog_name = "put_idv_bsdc_v1_2"
analyst = "Prof Evans"
# In this version the user provides expiry and the program calculates days.
#
exyear = int(2020)
exmonth = int(4)
exday = int (17)
#
stosym = "SPY"
stopr = float(247.95)
strike = float(245.00)
putBid = float(10.56)
putAsk = float(10.71)
rfir = float (0.0100)
#
#  Initialize key variables below
#
daystd = int(1)  # days reduction needed for time decay calculation, usually 1.
peg_spr = 0.50   # location in bid/ask spread for PEG
#
# Calculate the PEG and make that your call price (market value).
#
spread = putAsk - putBid
putpr = putBid + ((peg_spr)*spread)
#
#  END USER INPUT (no changes go below)
#
# Calculating days to expiry and converting the dates for printing:   
#
exp_mo = tu.monthname(exmonth)
big_day = tu.iso_daysto_days(exyear,exmonth,exday)
expiry, days = big_day
days_to_exp = int(days)
#
#  Divide and conquer requires that we initialize before we start to
#  converge, using default upper and lower ranges and desired precision.
#  The variable pipd will eventually become our solution.
#
target = putpr
precision = float(1e-3)
count = 0
low = 0.0
high = 1.0
pipd = float((high+low)/2)
temp_pp_tu = fu.popo_pitm(stopr,strike,pipd,days,rfir)  # passes out a tuple
temppp = temp_pp_tu[0]
while temppp<=(target-precision) or temppp>=(target+precision):
	if temppp >= (target+precision):
		high = pipd
	else: 
		low = pipd
	pipd = float((high+low)/2)
	temp_pp_tu = fu.popo_pitm(stopr,strike,pipd,days,rfir) 
	temppp = temp_pp_tu[0]
	count +=1  # The counter is in here only to test how many loops required for d&c.
#
delta = temp_pp_tu[1]
prob_itm = temp_pp_tu[3]
#
#	Below we calculate one day (or more) time decay using our new value for volatility
#
calc_time_decay= True 
if days > 1 and days > daystd:
	days = days - daystd 
	newcp = fu.popo_pitm(stopr,strike,pipd,days,rfir) 
	timedecay = putpr - newcp[0]
else:
	calc_time_decay = False
#
rightnow = tu.right_now()
print ("")
# print ("  Analyst: ", analyst)  # Use if turning in homework
print ("  Date: ", rightnow[0])
print ("  Model and version: ", prog_name)  # Very useful when logging results.
print ("  ASSUMPTIONS:")
print ("  Stock price: {:.3f}".format(stopr))
print ("  Strike price: {:.2f} ".format(strike))
print ("  Expiry is on {} {}, {} days from now.".format(exp_mo, exday, days_to_exp))
print ("  Interest rate: {:.3f} ".format(rfir))
print ("  Put Ask: {:.3f}".format(putAsk))
print ("  Put Bid: {:.3f}".format(putBid))
print ("  MODEL RESULTS:")
print ("  Put price (PEG): {:.3f}".format(putpr))
print ("  The delta: {:.4f}".format(delta))
print ("  The probability of ITM at expiry: {:.4f}".format(prob_itm))
if calc_time_decay:
	print ("  One day time decay: {:.3f}".format(timedecay))
else:
	print ("  Not enough time remaining to calculate time decay.")
print ("  The Put's implied probability: {:.5f}".format(pipd))
print ("  (Debug line): count (D&C looped this many times): ", count)           



